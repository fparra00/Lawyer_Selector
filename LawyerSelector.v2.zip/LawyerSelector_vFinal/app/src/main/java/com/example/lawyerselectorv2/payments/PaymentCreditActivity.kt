package com.example.lawyerselectorv2.payments

import android.content.DialogInterface
import android.os.Bundle
import android.os.Handler
import androidx.recyclerview.widget.RecyclerView

import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.lawyerselectorv2.R



import com.synap.pay.SynapPayButton;
import com.synap.pay.handler.EventHandler;
import com.synap.pay.handler.payment.SynapAuthorizeHandler;
import com.synap.pay.model.payment.SynapAddress;
import com.synap.pay.model.payment.SynapCardStorage;
import com.synap.pay.model.payment.SynapCountry;
import com.synap.pay.model.payment.SynapCurrency;
import com.synap.pay.model.payment.SynapDocument;
import com.synap.pay.model.payment.SynapFeatures;
import com.synap.pay.model.payment.SynapMetadata;
import com.synap.pay.model.payment.SynapOrder;
import com.synap.pay.model.payment.SynapPerson;
import com.synap.pay.model.payment.SynapProduct;
import com.synap.pay.model.payment.SynapSettings;
import com.synap.pay.model.payment.SynapTransaction;
import com.synap.pay.model.payment.response.SynapAuthorizeResponse;
import com.synap.pay.model.security.SynapAuthenticator;
import com.synap.pay.theming.SynapDarkTheme
import com.synap.pay.theming.SynapLightTheme;
import com.synap.pay.theming.SynapTheme;
import kotlinx.android.synthetic.main.activity_payment_credit.*
import java.security.MessageDigest


class PaymentCreditActivity : AppCompatActivity() {

    //Aux Vars
    private lateinit var paymentWidget: SynapPayButton
    private  var synapForm: FrameLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_credit)
        //Init Vars
        synapForm = synapFormR


        synapButtonR2.setOnClickListener {
            startPayment()
        }

        synapButtonR.setOnClickListener {
            paymentWidget.pay()
        }


    }

    private fun startPayment() {

        // Crea el objeto del widget de pago
        paymentWidget = SynapPayButton.create(synapForm)

        // Tema de fondo en la tarjeta (Light o Dark)
        // SynapTheme theme = new SynapLightTheme(); // Fondo de tarjeta claro
        val theme: SynapTheme = SynapDarkTheme() // Fondo de tarjeta oscuro
        SynapPayButton.setTheme(theme)

        // Seteo del ambiente ".SANDBOX" o ".PRODUCTION"
        SynapPayButton.setEnvironment(SynapPayButton.Environment.SANDBOX)

        // Seteo de los campos de transacción
        val transaction: SynapTransaction = this.buildTransaction()!!

        // Seteo de los campos de autenticación de seguridad
        val authenticator: SynapAuthenticator = this.buildAuthenticator(transaction)!!

        // Control de eventos en el formulario de pago
        SynapPayButton.setListener(object : EventHandler {
            override fun onEvent(event: SynapPayButton.Events?) {
                val paymentButton: Button
                when (event) {
                    SynapPayButton.Events.START_PAY -> {
                        paymentButton = findViewById(R.id.synapButtonR)
                        paymentButton.setVisibility(View.GONE)
                    }
                    SynapPayButton.Events.INVALID_CARD_FORM -> {
                        paymentButton = findViewById(R.id.synapButtonR)
                        paymentButton.setVisibility(View.VISIBLE)
                    }
                    SynapPayButton.Events.VALID_CARD_FORM -> {}
                }
            }
        })
        paymentWidget.configure( // Seteo de autenticación de seguridad y transacción
            authenticator,
            transaction,  // Manejo de la respuesta
            object : SynapAuthorizeHandler {
                override fun success(response: SynapAuthorizeResponse) {
                    Looper.prepare()
                    val resultSuccess = response.success
                    if (resultSuccess) {
                        val resultAccepted = response.result.accepted
                        val resultMessage = response.result.message
                        if (resultAccepted) {
                            // Agregue el código según la experiencia del cliente para la autorización
                            showMessage(resultMessage)
                        } else {
                            // Agregue el código según la experiencia del cliente para la denegación
                            showMessage(resultMessage)
                        }
                    } else {
                        val messageText = response.message.text
                        // Agregue el código de la experiencia que desee visualizar en un error
                        showMessage(messageText)
                    }
                    Looper.loop()
                }

                override fun failed(response: SynapAuthorizeResponse) {
                    Looper.prepare()
                    val messageText = response.message.text
                    // Agregue el código de la experiencia que desee visualizar en un error
                    showMessage(messageText)
                    Looper.loop()
                }
            }
        )
        val paymentButton: Button
        paymentButton = findViewById(R.id.synapButtonR)
        paymentButton.setVisibility(View.VISIBLE)
    }

    private fun buildTransaction(): SynapTransaction? {
        // Genere el número de orden, este es solo un ejemplo
        val number = System.currentTimeMillis().toString()

        // Seteo de los datos de transacción
        // Referencie al objeto país
        val country = SynapCountry()
        // Seteo del código de país
        country.code = "PER" // Código de País (ISO 3166-2)

        // Referencie al objeto moneda
        val currency = SynapCurrency()
        // Seteo del código de moneda
        currency.code = "PEN" // Código de Moneda - Alphabetic code (ISO 4217)

        //Seteo del monto
        val amount = "1.00"

        // Referencie al objeto cliente
        val customer = SynapPerson()
        // Seteo del cliente
        customer.name = "Javier"
        customer.lastName = "Pérez"

        // Referencie al objeto dirección del cliente
        val address = SynapAddress()
        // Seteo del pais (country), niveles de ubicación geográfica (levels), dirección (line1 y line2) y código postal (zip)
        address.country = "PER" // Código de País del cliente (ISO 3166-2)
        address.levels = ArrayList()
        address.levels.add("150000") // Código de Área (Ubigeo - Departamento)
        address.levels.add("150100") // Código de Área (Ubigeo - Provincia)
        address.levels.add("150101") // Código de Área (Ubigeo - Distrito)
        address.line1 = "Av La Solidaridad 103" // Dirección
        address.zip = "15034"
        customer.address = address

        // Seteo del email y teléfono
        customer.email = "javier.perez@synapsis.pe"
        customer.phone = "999888777"

        // Referencie al objeto documento del cliente
        val document = SynapDocument()
        // Seteo del tipo y número de documento
        document.type =
            "DNI" // [ DNI: Documento de identidad, CE: Carné de extranjería, PAS: Pasaporte, RUC: Registro único de contribuyente ]
        document.number = "44556677"
        customer.document = document

        // Seteo de los datos de envío
        // Seteo de los datos de facturación

        // Referencie al objeto producto
        val productItem = SynapProduct()
        // Seteo de los datos de producto
        productItem.code = "123" // Opcional
        productItem.name = "Llavero"
        productItem.quantity = "1" // Opcional
        productItem.unitAmount = "1.00" // Opcional
        productItem.amount = "1.00" // Opcional

        // Referencie al objeto lista de producto
        val products: MutableList<SynapProduct> = ArrayList()
        // Seteo de los datos de lista de producto
        products.add(productItem)

        // Referencie al objeto metadata - Opcional
        val metadataItem = SynapMetadata()
        // Seteo de los datos de metadata
        metadataItem.name = "name1"
        metadataItem.value = "value1"

        // Referencie al objeto lista de metadata - Opcional
        val metadataList: MutableList<SynapMetadata> = ArrayList()
        // Seteo de los datos de lista de metadata
        metadataList.add(metadataItem)

        // Referencie al objeto orden
        val order = SynapOrder()
        // Seteo de los datos de orden
        order.number = number
        order.amount = amount
        order.country = country
        order.currency = currency
        order.products = products
        order.customer = customer
        order.shipping = customer // Opcional
        order.billing = customer // Opcional
        order.metadata = metadataList // Opcional

        // Referencia al objeto features (Recordar Tarjeta) - Opcional
        val features = SynapFeatures()
        val cardStorage = SynapCardStorage()
        cardStorage.userIdentifier =
            "javier.perez@synapsis.pe" // Puede ser cualquier identificador definido por el comercio
        features.cardStorage = cardStorage

        // Referencie al objeto configuración
        val settings = SynapSettings()
        // Seteo de los datos de configuración
        settings.brands = listOf("VISA", "MSCD", "AMEX", "DINC")
        settings.language = "es_PE"
        settings.businessService = "MOB"

        // Referencie al objeto transacción
        val transaction = SynapTransaction()
        // Seteo de los datos de transacción
        transaction.order = order
        transaction.features = features
        transaction.settings = settings
        return transaction
    }

    private fun buildAuthenticator(transaction: SynapTransaction): SynapAuthenticator? {
        val apiKey = "ab254a10-ddc2-4d84-8f31-d3fab9d49520"

        // La signatureKey y la función de generación de firma debe usarse e implementarse en el servidor del comercio utilizando la función criptográfica SHA-512
        // solo con propósito de demostrar la funcionalidad, se implementará en el ejemplo
        // (bajo ninguna circunstancia debe exponerse la signatureKey y la función de firma desde la aplicación porque compromete la seguridad)
        val signatureKey = "eDpehY%YPYgsoludCSZhu*WLdmKBWfAo"
        val signature: String = generateSignature(transaction, apiKey, signatureKey)

        // El campo onBehalf es opcional y se usa cuando un comercio agrupa otros sub comercios
        // la conexión con cada sub comercio se realiza con las credenciales del comercio agrupador
        // y enviando el identificador del sub comercio en el campo onBehalf
        //String onBehalf="cf747220-b471-4439-9130-d086d4ca83d4";

        // Referencie el objeto de autenticación
        val authenticator = SynapAuthenticator()

        // Seteo de identificador del comercio (apiKey)
        authenticator.identifier = apiKey

        // Seteo de firma, que permite verificar la integridad de la transacción
        authenticator.signature = signature

        // Seteo de identificador de sub comercio (solo si es un subcomercio)
        //authenticator.setOnBehalf(onBehalf);
        return authenticator
    }

    // Muestra el mensaje de respuesta
    private fun showMessage(message: String) {
        val builder1: AlertDialog.Builder = AlertDialog.Builder(this)
        builder1.setMessage(message)
        builder1.setCancelable(true)
        builder1.setPositiveButton(
            "OK",
            DialogInterface.OnClickListener { dialog, id -> // Finaliza el intento de pago y regresa al inicio, el comercio define la experiencia del cliente
                val looper = Handler(applicationContext.mainLooper)
                looper.post(Runnable {
                    synapForm!!.visibility = View.GONE
                })
                dialog.cancel()
            }
        )
        val alert11: AlertDialog = builder1.create()
        alert11.show()
    }

    // La signatureKey y la función de generación de firma debe usarse e implementarse en el servidor del comercio utilizando la función criptográfica SHA-512
    // solo con propósito de demostrar la funcionalidad, se implementará en el ejemplo
    // (bajo ninguna circunstancia debe exponerse la signatureKey y la función de firma desde la aplicación porque compromete la seguridad)
    private fun generateSignature(
        transaction: SynapTransaction,
        apiKey: String,
        signatureKey: String
    ): String {
        val orderNumber = transaction.order.number
        val currencyCode = transaction.order.currency.code
        val amount = transaction.order.amount
        val rawSignature =
            apiKey + orderNumber + currencyCode + amount + signatureKey
        return sha512Hex(rawSignature)
    }

    private fun sha512Hex(value: String): String {
        val sb = StringBuilder()
        try {
            val md: MessageDigest = MessageDigest.getInstance("SHA-512")
            val bytes: ByteArray = md.digest(value.toByteArray(charset("UTF-8")))
            for (i in bytes.indices) {
                sb.append(Integer.toString((bytes[i] + 0xff) + 0x100, 16).substring(1))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return sb.toString()
    }
}