package com.example.lawyerselectorv2.customDialogs

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.lawyerselectorv2.R
import java.math.BigDecimal
import com.synap.pay.SynapPayButton

class cdPayPal : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

}